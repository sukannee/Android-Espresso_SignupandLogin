package com.sourcey.materiallogindemo;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({LoginTest.class, SignupTest.class})

public class UITestSuite {
}
