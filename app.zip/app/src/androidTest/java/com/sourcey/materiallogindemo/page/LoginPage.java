package com.sourcey.materiallogindemo.page;

import androidx.test.rule.ActivityTestRule;

import com.sourcey.materiallogindemo.LoginActivity;
import com.sourcey.materiallogindemo.R;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.withDecorView;
import static androidx.test.espresso.matcher.ViewMatchers.hasErrorText;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.not;

public class LoginPage {

    public ActivityTestRule<LoginActivity> rule;
    public LoginPage(ActivityTestRule<LoginActivity> rule) { this.rule = rule; }

    public LoginPage login(String email, String password) {
        return enterEmail(email)
                .enterPassword(password)
                .tapLoginButton();
        //.waitForLoginStatus();
    }

    /*public LoginPage clickLink_signup(){
        onView(withId(R.id.link_signup))
                .perform(click());
        return this;
    }*/

    private LoginPage enterEmail(String email) {
        onView(withId(R.id.input_email))
                .perform(typeText(email));
        return this;
    }

    private LoginPage enterPassword(String password) {
        onView(withId(R.id.input_password))
                .perform(typeText(password));
        return this;
    }

    private LoginPage tapLoginButton() {
        onView(withId(R.id.btn_login))
                .perform(click());
        return this;
    }

    /*public LoginPage expectStatusSuccess(String message) {
        onView(withText("Success"))
                .inRoot(withDecorView(not(rule.getActivity().getWindow().getDecorView())))
                .check(matches(isDisplayed()));
        return this;
    }*/

    public LoginPage expectHelloWorld(String message) {
        //progress dialog is now shown
        try{Thread.sleep(3000);}catch(InterruptedException e){System.out.println(e);}
        onView(withText("Hello world!")).check(matches(isDisplayed()));
        return this;
    }

    /*public LoginPage expectStatusFail(String message) {
        onView(withText("Login Failed"))
                .inRoot(withDecorView(not(rule.getActivity().getWindow().getDecorView())))
                .check(matches(isDisplayed()));
        return this;
    }*/

    public LoginPage expectEmailErrorMessage(String message) {
        onView(withId(R.id.input_email)).check(matches(hasErrorText(message)));
        return this;
    }

    public LoginPage expectPasswordErrorMessage(String message) {
        onView(withId(R.id.input_password)).check(matches(hasErrorText(message)));
        return this;
    }

    public LoginPage expectBothErrorMessage(String message) {
        onView(withId(R.id.input_password)).check(matches(hasErrorText(message)));
        return this;
    }

}

