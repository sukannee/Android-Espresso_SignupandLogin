package com.sourcey.materiallogindemo;


import androidx.test.espresso.assertion.ViewAssertions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import com.sourcey.materiallogindemo.page.LoginPage;

import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.pressImeActionButton;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class LoginTest {

    private LoginPage loginPage;

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule1 = new ActivityTestRule<>(MainActivity.class);

    @Rule
    public ActivityTestRule<LoginActivity> mActivityTestRule2 = new ActivityTestRule<>(LoginActivity.class);

    @Before
    public void setupTest() {
        loginPage = new LoginPage(mActivityTestRule2);
    }

    @Test
    public void signupAndLogin() {
        onView(withId(R.id.link_signup)).perform(click());
        onView(withId(R.id.input_name)).perform((typeText(LoginTestData.NAME)), pressImeActionButton());
        onView(withId(R.id.input_address)).perform((typeText(LoginTestData.ADDRESS)), pressImeActionButton());
        onView(withId(R.id.input_email)).perform((typeText(LoginTestData.EMAIL)), pressImeActionButton());
        onView(withId(R.id.input_mobile)).perform((typeText(LoginTestData.MOBILE)), pressImeActionButton());
        onView(withId(R.id.input_password)).perform(typeText(LoginTestData.PASSWORD), pressImeActionButton());
        onView(withId(R.id.input_reEnterPassword)).perform(typeText(LoginTestData.REPASSWORD),closeSoftKeyboard());
        onView(withId(R.id.btn_signup)).perform(click());

        //progress dialog is now shown
        try{Thread.sleep(3000);}catch(InterruptedException e){System.out.println(e);}

        onView(withText("Hello world!")).check(matches(isDisplayed()));
        onView(withId(R.id.btn_logout)).perform(click());
    }

    /*@Test
    public void loginSuccessWithToast() {
        loginPage.login(LoginTestData.EMAIL,
                LoginTestData.PASSWORD)
                .expectStatusSuccess(LoginTestData.LOGIN_SUCCESS);
                //.expectHelloWorld(LoginTestData.HELLO_WORLD);
    }*/

    @Test
    public void loginSuccess() {
        loginPage.login(LoginTestData.EMAIL,
                LoginTestData.PASSWORD)
                //.expectStatusSuccess(LoginTestData.LOGIN_SUCCESS);
                .expectHelloWorld(LoginTestData.HELLO_WORLD);
    }

    @Test
    public void emptyEmail() {
        loginPage.login("", LoginTestData.PASSWORD)
                //.expectStatusFail(LoginTestData.LOGIN_FAIL)
                .expectEmailErrorMessage(LoginTestData.ENTER_EMAIL);
    }

    @Test
    public void invalidEmail() {
        loginPage.login(LoginTestData.INVALID_EMAIL, LoginTestData.PASSWORD)
                //.expectStatusFail(LoginTestData.LOGIN_FAIL)
                .expectEmailErrorMessage(LoginTestData.ENTER_EMAIL);
    }

    @Test
    public void emptyPassword() {
        loginPage.login(LoginTestData.EMAIL, "")
                //.expectStatusFail(LoginTestData.LOGIN_FAIL);
                .expectPasswordErrorMessage(LoginTestData.ENTER_PASSWORD);
    }

    /*@Test
    public void invalidPasswordWithToast() {
        loginPage.login(LoginTestData.EMAIL,
                LoginTestData.INVALID_PASSWORD)
                .expectStatusFail(LoginTestData.LOGIN_FAIL);
                //.expectBothErrorMessage(LoginTestData.ENTER_BOTH);
    }*/

    @Test
    public void invalidPassword() {
        loginPage.login(LoginTestData.EMAIL,
                LoginTestData.INVALID_PASSWORD)
                //.expectStatusFail(LoginTestData.LOGIN_FAIL);
                .expectBothErrorMessage(LoginTestData.ENTER_BOTH);
    }

    @Test
    public void invalidPasswordLessLength() {
        loginPage.login(LoginTestData.EMAIL, LoginTestData.SHORT_PASSWORD)
                //.expectStatusFail(LoginTestData.LOGIN_FAIL)
                .expectPasswordErrorMessage(LoginTestData.ENTER_PASSWORD);
    }

    @Test
    public void invalidPasswordMoreLength() {
        loginPage.login(LoginTestData.EMAIL, LoginTestData.LONG_PASSWORD)
                //.expectStatusFail(LoginTestData.LOGIN_FAIL)
                .expectPasswordErrorMessage(LoginTestData.ENTER_PASSWORD);
    }

    @Test
    public void emptyEmailAndPassword() {
        loginPage.login("", "")
                //.expectStatusFail(LoginTestData.LOGIN_FAIL)
                .expectEmailErrorMessage(LoginTestData.ENTER_EMAIL)
                .expectPasswordErrorMessage(LoginTestData.ENTER_PASSWORD);
    }

}
