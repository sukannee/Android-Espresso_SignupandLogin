package com.sourcey.materiallogindemo;

public class LoginTestData {

    //Test data for pass
    public static String NAME = "Sukannee Photiprasit";
    public static String ADDRESS = "1 RAMA3/53 Rd., Yannawa, Bangkok 10120";
    public static String EMAIL = "sukannee.phot@gmail.com";
    public static String MOBILE = "0917166324";
    public static String PASSWORD = "Passw0rd";
    public static String REPASSWORD = "Passw0rd";

    //Test data for fail(
    public static String INVALID_EMAIL = "sukannee.phot";
    public static String INVALID_PASSWORD = "Password";
    public static String SHORT_PASSWORD = "12";
    public static String LONG_PASSWORD = "PwdMoreThanTen";
    public static String INVALID_NAME = "Su";
    public static String INVALID_MOBILE = "123456";
    public static String NOTMATCH_PASSWORD = "testtest";

    //Expect messages
    public static String ENTER_NAME = "at least 3 characters";
    public static String ENTER_ADDRESS = "Enter Valid Address";
    public static String ENTER_EMAIL = "enter a valid email address";
    public static String ENTER_PASSWORD = "between 4 and 10 alphanumeric characters";
    public static String ENTER_MATCHPWD = "Password Do not match";
    public static String ENTER_BOTH = "enter a valid email address or password";
    public static String ENTER_MOBILE = "Enter Valid Mobile Number";
    //public static String LOGIN_SUCCESS = "Success";
    public static String HELLO_WORLD = "Hello world!";
    //public static String LOGIN_FAIL = "Login failed";
}
