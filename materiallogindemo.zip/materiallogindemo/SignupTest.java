package com.sourcey.materiallogindemo;

import com.sourcey.materiallogindemo.page.SignupPage;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import androidx.test.rule.ActivityTestRule;

public class SignupTest {

    private SignupPage signupPage;

    @Rule
    public ActivityTestRule<SignupActivity> rule = new ActivityTestRule(SignupActivity.class);

    @Before
    public void setupTest() {
        signupPage = new SignupPage(rule);
    }

    @Test
    public void emtryName() {
        signupPage.signup("",
                LoginTestData.ADDRESS,
                LoginTestData.EMAIL,
                LoginTestData.MOBILE,
                LoginTestData.PASSWORD,
                LoginTestData.REPASSWORD)
                .expectNameErrorMessage(LoginTestData.ENTER_NAME);
    }

    @Test
    public void invalidName() {
        signupPage.signup(LoginTestData.INVALID_NAME,
                LoginTestData.ADDRESS,
                LoginTestData.EMAIL,
                LoginTestData.MOBILE,
                LoginTestData.PASSWORD,
                LoginTestData.REPASSWORD)
                .expectNameErrorMessage(LoginTestData.ENTER_NAME);
    }

    @Test
    public void emtryAddress() {
        signupPage.signup(LoginTestData.NAME,
                "",
                LoginTestData.EMAIL,
                LoginTestData.MOBILE,
                LoginTestData.PASSWORD,
                LoginTestData.REPASSWORD)
                .expectAddressErrorMessage(LoginTestData.ENTER_ADDRESS);
    }

    @Test
    public void emtryEmail() {
        signupPage.signup(LoginTestData.NAME,
                LoginTestData.ADDRESS,
                "",
                LoginTestData.MOBILE,
                LoginTestData.PASSWORD,
                LoginTestData.REPASSWORD)
                .expectEmailErrorMessage(LoginTestData.ENTER_EMAIL);
    }

    @Test
    public void invalidEmail() {
        signupPage.signup(LoginTestData.NAME,
                LoginTestData.ADDRESS,
                LoginTestData.INVALID_EMAIL,
                LoginTestData.MOBILE,
                LoginTestData.PASSWORD,
                LoginTestData.REPASSWORD)
                .expectEmailErrorMessage(LoginTestData.ENTER_EMAIL);
    }

    @Test
    public void emtryMobile() {
        signupPage.signup(LoginTestData.NAME,
                LoginTestData.ADDRESS,
                LoginTestData.EMAIL,
                "",
                LoginTestData.PASSWORD,
                LoginTestData.REPASSWORD)
                .expectMobileErrorMessage(LoginTestData.ENTER_MOBILE);
    }

    @Test
    public void invalidMobile() {
        signupPage.signup(LoginTestData.NAME,
                LoginTestData.ADDRESS,
                LoginTestData.EMAIL,
                LoginTestData.INVALID_MOBILE,
                LoginTestData.PASSWORD,
                LoginTestData.REPASSWORD)
                .expectMobileErrorMessage(LoginTestData.ENTER_MOBILE);
    }

    @Test
    public void emtryPassword() {
        signupPage.signup(LoginTestData.NAME,
                LoginTestData.ADDRESS,
                LoginTestData.EMAIL,
                LoginTestData.MOBILE,
                "",
                LoginTestData.REPASSWORD)
                .expectPasswordErrorMessage(LoginTestData.ENTER_PASSWORD);
    }

    @Test
    public void shortPasswordAndEmtryRepassword() {
        signupPage.signup(LoginTestData.NAME,
                LoginTestData.ADDRESS,
                LoginTestData.EMAIL,
                LoginTestData.MOBILE,
                LoginTestData.SHORT_PASSWORD,
                "")
                .expectPasswordErrorMessage(LoginTestData.ENTER_PASSWORD)
                .expectRepasswordErrorMessage(LoginTestData.ENTER_MATCHPWD);
    }

    @Test
    public void longPasswordAndShortRepassword() {
        signupPage.signup(LoginTestData.NAME,
                LoginTestData.ADDRESS,
                LoginTestData.EMAIL,
                LoginTestData.MOBILE,
                LoginTestData.LONG_PASSWORD,
                LoginTestData.SHORT_PASSWORD)
                .expectPasswordErrorMessage(LoginTestData.ENTER_PASSWORD)
                .expectRepasswordErrorMessage(LoginTestData.ENTER_MATCHPWD);
    }

    @Test
    public void notMatchPassword() {
        signupPage.signup(LoginTestData.NAME,
                LoginTestData.ADDRESS,
                LoginTestData.EMAIL,
                LoginTestData.MOBILE,
                LoginTestData.PASSWORD,
                LoginTestData.NOTMATCH_PASSWORD)
                .expectRepasswordErrorMessage(LoginTestData.ENTER_MATCHPWD);
    }

    @Test
    public void longRepassword() {
        signupPage.signup(LoginTestData.NAME,
                LoginTestData.ADDRESS,
                LoginTestData.EMAIL,
                LoginTestData.MOBILE,
                LoginTestData.PASSWORD,
                LoginTestData.LONG_PASSWORD)
                .expectRepasswordErrorMessage(LoginTestData.ENTER_MATCHPWD);
    }

    @Test
    public void allEmtry() {
        signupPage.signup("",
                "",
                "",
                "",
                "",
                "")
                .expectNameErrorMessage(LoginTestData.ENTER_NAME)
                .expectAddressErrorMessage(LoginTestData.ENTER_ADDRESS)
                .expectEmailErrorMessage(LoginTestData.ENTER_EMAIL)
                .expectMobileErrorMessage(LoginTestData.ENTER_MOBILE)
                .expectPasswordErrorMessage(LoginTestData.ENTER_PASSWORD)
                .expectRepasswordErrorMessage(LoginTestData.ENTER_MATCHPWD);
    }

}
