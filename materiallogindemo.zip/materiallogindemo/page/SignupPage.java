package com.sourcey.materiallogindemo.page;

import androidx.test.rule.ActivityTestRule;

import com.sourcey.materiallogindemo.SignupActivity;
import com.sourcey.materiallogindemo.R;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.pressImeActionButton;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasErrorText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.not;

public class SignupPage {

    public ActivityTestRule<SignupActivity> rule;
    public SignupPage(ActivityTestRule<SignupActivity> rule) { this.rule = rule; }

    public SignupPage signup(String name,
                             String address,
                             String email,
                             String mobile,
                             String password,
                             String reenterpassword) {
        return enterName(name)
                .enterAddress(address)
                .enterEmail(email)
                .enterMobile(mobile)
                .enterPassword(password)
                .enterRepassword(reenterpassword)
                .tapSignupButton();
        //.waitForLoginStatus();
    }

    /*private SignupPage clickLink_signup(){
        onView(withId(R.id.link_signup))
                .perform(click());
        return this;
    }*/

    private SignupPage enterName(String name) {
        onView(withId(R.id.input_name))
                .perform((typeText(name)),pressImeActionButton());
        return this;
    }

    private SignupPage enterAddress(String address) {
        onView(withId(R.id.input_address))
                .perform((typeText(address)),pressImeActionButton());
        return this;
    }

    private SignupPage enterEmail(String email) {
        onView(withId(R.id.input_email))
                .perform((typeText(email)),pressImeActionButton());
        return this;
    }

    private SignupPage enterMobile(String mobile) {
        onView(withId(R.id.input_mobile))
                .perform((typeText(mobile)),pressImeActionButton());
        return this;
    }

    private SignupPage enterPassword(String password) {
        onView(withId(R.id.input_password))
                .perform((typeText(password)),pressImeActionButton());
        return this;
    }

    private SignupPage enterRepassword(String repassword) {
        onView(withId(R.id.input_reEnterPassword))
                .perform((typeText(repassword)),closeSoftKeyboard());
        return this;
    }

    private SignupPage tapSignupButton() {
        onView(withId(R.id.btn_signup))
                .perform(click());
        return this;
    }

    public SignupPage expectNameErrorMessage(String message) {
        onView(withId(R.id.input_name)).check(matches(hasErrorText(message)));
        return this;
    }

    public SignupPage expectAddressErrorMessage(String message) {
        onView(withId(R.id.input_address)).check(matches(hasErrorText(message)));
        return this;
    }

    public SignupPage expectEmailErrorMessage(String message) {
        onView(withId(R.id.input_email)).check(matches(hasErrorText(message)));
        return this;
    }

    public SignupPage expectMobileErrorMessage(String message) {
        onView(withId(R.id.input_mobile)).check(matches(hasErrorText(message)));
        return this;
    }

    public SignupPage expectPasswordErrorMessage(String message) {
        onView(withId(R.id.input_password)).check(matches(hasErrorText(message)));
        return this;
    }

    public SignupPage expectRepasswordErrorMessage(String message) {
        onView(withId(R.id.input_reEnterPassword)).check(matches(hasErrorText(message)));
        return this;
    }

}
